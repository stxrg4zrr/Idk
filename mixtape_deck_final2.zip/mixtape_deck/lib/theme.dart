import 'package:flutter/material.dart';

const kBlack = Color(0xFF0D0D0D);
const kCard = Color(0xFF181818);
const kChip = Color(0xFF1F1F1F);
const kPill = Color(0xEB262626);
const kOrange = Color(0xFFFF5500);
const kGreen = Color(0xFF00E676);
const kOrangeSoft = Color(0x33FF5500);
const kMuted = Color(0xFF9A9A9A);

/// Playlist theme colors (stored as ints).
const kPlaylistColorValues = <int>[
  0xFFFF5500, // cassette orange
  0xFF00E676, // neon green
  0xFFB388FF, // purple
  0xFFFF5252, // red
  0xFF40C4FF, // blue
  0xFFFFD740, // yellow
  0xFFFF80AB, // pink
  0xFF1DE9B6, // teal
];

ThemeData buildTheme() {
  final base = ThemeData.dark(useMaterial3: true);
  return base.copyWith(
    scaffoldBackgroundColor: kBlack,
    colorScheme: const ColorScheme.dark(
      primary: kOrange,
      onPrimary: Colors.black,
      secondary: kGreen,
      surface: kCard,
    ),
    appBarTheme: const AppBarTheme(
      backgroundColor: kBlack,
      surfaceTintColor: Colors.transparent,
      elevation: 0,
    ),
    bottomSheetTheme: const BottomSheetThemeData(
      backgroundColor: kCard,
      surfaceTintColor: Colors.transparent,
    ),
    snackBarTheme: const SnackBarThemeData(
      backgroundColor: kCard,
      contentTextStyle: TextStyle(color: Colors.white),
      behavior: SnackBarBehavior.floating,
    ),
  );
}
