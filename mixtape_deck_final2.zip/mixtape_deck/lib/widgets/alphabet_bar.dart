import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../utils.dart';

/// A-Z + # scroller shown on the side of the Tapes list.
class AlphabetBar extends StatelessWidget {
  const AlphabetBar({super.key, required this.onLetter, required this.onEnd});

  final ValueChanged<String> onLetter;
  final VoidCallback onEnd;

  static const letters = [
    'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M',
    'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', '#',
  ];

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, c) {
        final itemH = math.min(24.0, (c.maxHeight - 16) / letters.length);
        final total = itemH * letters.length + 16;

        void handle(double dy) {
          final i = clampInt(((dy - 8) / itemH).floor(), 0, letters.length - 1);
          onLetter(letters[i]);
        }

        return Center(
          child: GestureDetector(
            behavior: HitTestBehavior.opaque,
            onTapDown: (d) => handle(d.localPosition.dy),
            onTapUp: (_) => onEnd(),
            onTapCancel: onEnd,
            onVerticalDragStart: (d) => handle(d.localPosition.dy),
            onVerticalDragUpdate: (d) => handle(d.localPosition.dy),
            onVerticalDragEnd: (_) => onEnd(),
            onVerticalDragCancel: onEnd,
            child: Container(
              width: 34,
              height: total,
              padding: const EdgeInsets.symmetric(vertical: 8),
              decoration: BoxDecoration(
                color: const Color(0xCC1A1A1A),
                borderRadius: BorderRadius.circular(17),
                border: Border.all(color: const Color(0x33FFFFFF)),
              ),
              child: Column(
                children: [
                  for (final l in letters)
                    SizedBox(
                      height: itemH,
                      child: Center(
                        child: Text(
                          l,
                          style: TextStyle(
                            fontSize: math.min(14.0, itemH * 0.62),
                            fontWeight: FontWeight.w800,
                            color: Colors.white70,
                          ),
                        ),
                      ),
                    ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
