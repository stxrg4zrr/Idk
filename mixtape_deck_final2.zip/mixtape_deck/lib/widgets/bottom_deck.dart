import 'dart:math';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../library_store.dart';
import '../player_controller.dart';
import '../screens/now_playing_screen.dart';
import '../theme.dart';
import 'cover_image.dart';
import 'eat_tape.dart';

Future<void> shuffleWholeLibrary(BuildContext context) async {
  final store = context.read<LibraryStore>();
  final pl = context.read<PlayerController>();
  final all = store.allAudio;
  if (all.isEmpty) {
    ScaffoldMessenger.of(context)
        .showSnackBar(const SnackBar(content: Text('Eat a tape first')));
    return;
  }
  await pl.playQueue(all, Random().nextInt(all.length), shuffleOn: true);
}

/// Floating bar: "Swipe to Shuffle" when idle, the mini-player when something
/// is playing (swipe left = next, swipe right = previous, tap = Now Playing).
/// The square "+" button next to it is the Eat Tape import button.
class BottomDeck extends StatefulWidget {
  const BottomDeck({super.key, this.showAdd = true});

  final bool showAdd;

  @override
  State<BottomDeck> createState() => _BottomDeckState();
}

class _BottomDeckState extends State<BottomDeck> {
  double _dx = 0;

  @override
  Widget build(BuildContext context) {
    final pl = context.watch<PlayerController>();
    final r = pl.current;

    final pill = GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: () {
        if (r == null) {
          shuffleWholeLibrary(context);
        } else {
          openNowPlaying(context);
        }
      },
      onHorizontalDragUpdate: (d) => setState(() => _dx += d.delta.dx),
      onHorizontalDragEnd: (d) {
        final moved = _dx;
        final v = d.primaryVelocity ?? 0;
        setState(() => _dx = 0);
        final swiped = moved.abs() > 60 || v.abs() > 700;
        if (!swiped) return;
        if (r == null) {
          shuffleWholeLibrary(context);
        } else if (moved < 0 || v < 0) {
          pl.next();
        } else {
          pl.previous();
        }
      },
      child: Container(
        height: 76,
        padding: const EdgeInsets.fromLTRB(10, 10, 6, 10),
        decoration: BoxDecoration(
          color: kPill,
          borderRadius: BorderRadius.circular(28),
        ),
        child: Transform.translate(
          offset: Offset(_dx.clamp(-120.0, 120.0).toDouble(), 0),
          child: Row(
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(14),
                child: SizedBox(
                  width: 56,
                  height: 56,
                  child: CoverImage(path: r?.album.coverPath, cacheWidth: 160),
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: r == null
                    ? const Text(
                        'Swipe to Shuffle',
                        style: TextStyle(fontSize: 20, fontWeight: FontWeight.w300),
                      )
                    : Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            r.track.title,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                                fontSize: 17, fontWeight: FontWeight.w700),
                          ),
                          Text(
                            r.album.artist,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(color: kMuted, fontSize: 14),
                          ),
                        ],
                      ),
              ),
              if (r != null)
                IconButton(
                  onPressed: pl.toggle,
                  icon: Icon(
                    pl.playing ? Icons.pause_circle_filled : Icons.play_circle_fill,
                    size: 44,
                    color: kOrange,
                  ),
                ),
            ],
          ),
        ),
      ),
    );

    return SafeArea(
      top: false,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
        child: Row(
          children: [
            Expanded(child: pill),
            if (widget.showAdd) ...[
              const SizedBox(width: 12),
              GestureDetector(
                onTap: () => eatTape(context),
                child: Container(
                  width: 76,
                  height: 76,
                  decoration: BoxDecoration(
                    color: kPill,
                    borderRadius: BorderRadius.circular(28),
                  ),
                  child: const Icon(Icons.add, size: 38),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
