import 'dart:io';
import 'dart:typed_data';

import 'package:archive/archive_io.dart';
import 'package:audio_metadata_reader/audio_metadata_reader.dart';
import 'package:flutter/foundation.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

import 'models.dart';

const _audioExt = {'.mp3', '.m4a', '.wav', '.aac', '.flac', '.ogg'};
const _videoExt = {'.mp4', '.mov', '.m4v'};
const _imageExt = {'.jpg', '.jpeg', '.png'};
const _coverNames = ['cover', 'folder', 'front', 'album', 'artwork'];

/// Runs in a background isolate. args = [zipPath, destDir].
/// Streams the zip to disk (never loads a whole zip or a whole video in memory).
Future<int> extractZip(List<String> args) async {
  final zipPath = args[0];
  final dest = args[1];

  var files = 0;
  final input = InputFileStream(zipPath);
  try {
    final archive = ZipDecoder().decodeBuffer(input);
    for (final f in archive.files) {
      final name = f.name.replaceAll('\\', '/');
      if (name.startsWith('/') ||
          name.split('/').contains('..') ||
          RegExp(r'^[A-Za-z]:').hasMatch(name)) {
        throw Exception('Unsafe file path inside the zip');
      }
      if (f.isFile) files++;
    }
  } finally {
    await input.close();
  }
  if (files == 0) throw Exception('That zip is empty');

  await extractFileToDisk(zipPath, dest);
  return files;
}

T? _try<T>(T? Function() f) {
  try {
    return f();
  } catch (_) {
    return null;
  }
}

class _Entry {
  _Entry(this.file, this.title, this.number);
  final File file;
  final String title;
  final int number;
}

bool _junk(File f) {
  final n = p.basename(f.path);
  return n.startsWith('._') || f.path.contains('__MACOSX');
}

String _titleFromFilename(String path) {
  var t = p.basenameWithoutExtension(path).replaceAll('_', ' ');
  t = t.replaceFirst(RegExp(r'^\d+\s*[.\-]*\s*'), '');
  return t.trim().isEmpty ? p.basenameWithoutExtension(path) : t.trim();
}

String? _pickCover(List<File> images) {
  if (images.isEmpty) return null;
  for (final key in _coverNames) {
    for (final f in images) {
      if (p.basenameWithoutExtension(f.path).toLowerCase().contains(key)) {
        return f.path;
      }
    }
  }
  return images.first.path;
}

/// Runs in a background isolate. args = [destDir, displayName, id].
/// Reads tags + cover and returns the album as JSON.
Map<String, dynamic> scanAlbum(List<String> args) {
  final dest = args[0];
  final displayName = args[1];
  final id = args[2];

  final all = <File>[];
  for (final e in Directory(dest).listSync(recursive: true, followLinks: false)) {
    if (e is File && !_junk(e)) all.add(e);
  }

  final media = all.where((f) {
    final e = p.extension(f.path).toLowerCase();
    return _audioExt.contains(e) || _videoExt.contains(e);
  }).toList()
    ..sort((a, b) => a.path.toLowerCase().compareTo(b.path.toLowerCase()));

  if (media.isEmpty) {
    throw Exception('No playable audio or video files in that zip');
  }

  final images = all
      .where((f) => _imageExt.contains(p.extension(f.path).toLowerCase()))
      .toList();

  final entries = <_Entry>[];
  Uint8List? art;
  String? artistTag;
  String? albumTag;

  for (final f in media) {
    String? title;
    int? no;
    try {
      final dynamic md = readMetadata(f, getImage: art == null);
      title = _try<String>(() => md.title as String?);
      no = _try<int>(() => md.trackNumber as int?);
      final artist = _try<String>(() => md.artist as String?);
      final album = _try<String>(() => md.album as String?);
      if (artistTag == null && artist != null && artist.trim().isNotEmpty) {
        artistTag = artist.trim();
      }
      if (albumTag == null && album != null && album.trim().isNotEmpty) {
        albumTag = album.trim();
      }
      if (art == null) {
        final pics = _try<List>(() => md.pictures as List?);
        if (pics != null && pics.isNotEmpty) {
          final b = pics.first.bytes;
          if (b is List<int> && b.isNotEmpty) art = Uint8List.fromList(b);
        }
      }
    } catch (_) {}
    entries.add(_Entry(
      f,
      (title != null && title.trim().isNotEmpty)
          ? title.trim()
          : _titleFromFilename(f.path),
      no ?? 0,
    ));
  }

  entries.sort((a, b) {
    final an = a.number == 0 ? 99999 : a.number;
    final bn = b.number == 0 ? 99999 : b.number;
    if (an != bn) return an.compareTo(bn);
    return a.file.path.toLowerCase().compareTo(b.file.path.toLowerCase());
  });

  String? coverPath = _pickCover(images);
  if (coverPath == null && art != null) {
    final cf = File(p.join(dest, 'cover_embedded.jpg'));
    cf.writeAsBytesSync(art);
    coverPath = cf.path;
  }

  final tracks = <Track>[];
  for (var i = 0; i < entries.length; i++) {
    final e = entries[i];
    tracks.add(Track(
      id: '${id}_$i',
      title: e.title,
      path: e.file.path,
      number: i + 1,
      isVideo: _videoExt.contains(p.extension(e.file.path).toLowerCase()),
    ));
  }

  return Album(
    id: id,
    title: albumTag ??
        p.basenameWithoutExtension(displayName).replaceAll('_', ' ').trim(),
    artist: artistTag ?? 'Unknown Artist',
    dirPath: dest,
    coverPath: coverPath,
    tracks: tracks,
  ).toJson();
}

class Importer {
  static Future<Album> importZip(String zipPath, String displayName) async {
    final docs = await getApplicationDocumentsDirectory();
    final id = DateTime.now().microsecondsSinceEpoch.toString();
    final dest = p.join(docs.path, 'tapes', id);
    await Directory(dest).create(recursive: true);

    try {
      await compute(extractZip, <String>[zipPath, dest]);
      final json =
          await compute(scanAlbum, <String>[dest, displayName, id]);
      return Album.fromJson(Map<String, dynamic>.from(json));
    } catch (e) {
      try {
        await Directory(dest).delete(recursive: true);
      } catch (_) {}
      rethrow;
    }
  }
}
