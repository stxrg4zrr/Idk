import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../library_store.dart';
import '../theme.dart';
import '../widgets/bottom_deck.dart';
import 'playlists_tab.dart';
import 'settings_screen.dart';
import 'tapes_tab.dart';
import 'video_tab.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _tab = 0;
  bool _searching = false;

  static const _names = ['Tapes', 'Playlists', 'Video'];

  @override
  Widget build(BuildContext context) {
    final store = context.watch<LibraryStore>();

    return Scaffold(
      body: SafeArea(
        bottom: false,
        child: Stack(
          children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 14, 8, 0),
                  child: Row(
                    children: [
                      const Expanded(
                        child: Text(
                          'TAPE EATER',
                          style: TextStyle(
                            fontSize: 32,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 2.5,
                          ),
                        ),
                      ),
                      IconButton(
                        iconSize: 30,
                        icon: Icon(_searching ? Icons.close : Icons.search),
                        onPressed: () {
                          setState(() => _searching = !_searching);
                          if (!_searching) store.setQuery('');
                        },
                      ),
                      IconButton(
                        iconSize: 30,
                        icon: const Icon(Icons.settings),
                        onPressed: () => Navigator.of(context).push(
                            MaterialPageRoute<void>(
                                builder: (_) => const SettingsScreen())),
                      ),
                    ],
                  ),
                ),
                if (_searching)
                  Padding(
                    padding: const EdgeInsets.fromLTRB(20, 12, 20, 0),
                    child: TextField(
                      autofocus: true,
                      onChanged: store.setQuery,
                      decoration: InputDecoration(
                        hintText: 'Search title or artist',
                        prefixIcon: const Icon(Icons.search),
                        filled: true,
                        fillColor: kCard,
                        contentPadding: EdgeInsets.zero,
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(14),
                          borderSide: BorderSide.none,
                        ),
                      ),
                    ),
                  ),
                const SizedBox(height: 18),
                SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Row(
                    children: [
                      for (var i = 0; i < _names.length; i++) ...[
                        GestureDetector(
                          onTap: () => setState(() => _tab = i),
                          child: Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 26, vertical: 16),
                            decoration: BoxDecoration(
                              color: _tab == i ? kOrange : kChip,
                              borderRadius: BorderRadius.circular(22),
                            ),
                            child: Text(
                              _names[i],
                              style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.w700,
                                color: _tab == i ? Colors.black : Colors.white,
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(width: 12),
                      ],
                    ],
                  ),
                ),
                if (store.importing) ...[
                  const SizedBox(height: 10),
                  LinearProgressIndicator(
                    value: store.progress,
                    color: kOrange,
                    backgroundColor: Colors.white12,
                    minHeight: 3,
                  ),
                  Padding(
                    padding: const EdgeInsets.fromLTRB(20, 6, 20, 0),
                    child: Text(store.status ?? 'Working…',
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(color: kMuted, fontSize: 12)),
                  ),
                ],
                const SizedBox(height: 6),
                Expanded(
                  child: IndexedStack(
                    index: _tab,
                    children: const [TapesTab(), PlaylistsTab(), VideoTab()],
                  ),
                ),
              ],
            ),
            const Positioned(
              left: 0,
              right: 0,
              bottom: 0,
              child: BottomDeck(),
            ),
          ],
        ),
      ),
    );
  }
}
