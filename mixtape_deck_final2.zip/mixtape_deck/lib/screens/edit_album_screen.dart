import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';

import '../library_store.dart';
import '../models.dart';
import '../theme.dart';
import '../widgets/cover_image.dart';

/// Rename the album/artist/tracks and pick a custom cover from the gallery.
/// Changes are saved inside the app's library (original files are not touched).
class EditAlbumScreen extends StatefulWidget {
  const EditAlbumScreen({super.key, required this.album});

  final Album album;

  @override
  State<EditAlbumScreen> createState() => _EditAlbumScreenState();
}

class _EditAlbumScreenState extends State<EditAlbumScreen> {
  late final TextEditingController _title;
  late final TextEditingController _artist;
  late final Map<String, TextEditingController> _tracks;

  @override
  void initState() {
    super.initState();
    _title = TextEditingController(text: widget.album.title);
    _artist = TextEditingController(text: widget.album.artist);
    _tracks = {
      for (final t in widget.album.tracks) t.id: TextEditingController(text: t.title),
    };
  }

  @override
  void dispose() {
    _title.dispose();
    _artist.dispose();
    for (final c in _tracks.values) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _pickCover() async {
    final store = context.read<LibraryStore>();
    final x = await ImagePicker().pickImage(source: ImageSource.gallery, maxWidth: 1600);
    if (x == null) return;
    await store.setAlbumCover(widget.album, x.path);
  }

  Future<void> _save() async {
    final store = context.read<LibraryStore>();
    await store.updateAlbum(
      widget.album,
      title: _title.text,
      artist: _artist.text,
      trackTitles: {for (final e in _tracks.entries) e.key: e.value.text},
    );
    if (mounted) Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    context.watch<LibraryStore>();
    return Scaffold(
      appBar: AppBar(
        title: const Text('Edit tape'),
        actions: [
          TextButton(
            onPressed: _save,
            child: const Text('SAVE',
                style: TextStyle(color: kOrange, fontWeight: FontWeight.w800)),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Center(
            child: SizedBox(
              width: 200,
              height: 200,
              child: ClipRRect(
                borderRadius: BorderRadius.circular(14),
                child: CoverImage(path: widget.album.coverPath, cacheWidth: 600),
              ),
            ),
          ),
          const SizedBox(height: 12),
          Center(
            child: TextButton.icon(
              onPressed: _pickCover,
              icon: const Icon(Icons.image_outlined),
              label: const Text('Change cover from gallery'),
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _title,
            decoration: const InputDecoration(labelText: 'Album / mixtape title'),
          ),
          const SizedBox(height: 14),
          TextField(
            controller: _artist,
            decoration: const InputDecoration(labelText: 'Artist'),
          ),
          const SizedBox(height: 24),
          const Text('TRACKS',
              style: TextStyle(
                  color: kOrange,
                  fontWeight: FontWeight.w800,
                  letterSpacing: 1.5,
                  fontSize: 12)),
          const SizedBox(height: 8),
          for (var i = 0; i < widget.album.tracks.length; i++)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 6),
              child: TextField(
                controller: _tracks[widget.album.tracks[i].id],
                decoration: InputDecoration(
                  prefixText: '${i + 1}   ',
                  prefixStyle: const TextStyle(color: kMuted),
                  isDense: true,
                ),
              ),
            ),
          const SizedBox(height: 40),
        ],
      ),
    );
  }
}
