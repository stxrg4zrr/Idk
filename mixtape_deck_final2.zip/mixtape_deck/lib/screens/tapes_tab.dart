import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../library_store.dart';
import '../models.dart';
import '../player_controller.dart';
import '../theme.dart';
import '../utils.dart';
import '../widgets/alphabet_bar.dart';
import '../widgets/cover_image.dart';
import '../widgets/menus.dart';
import 'album_screen.dart';

const double _rowH = 108;
const double _pinnedH = 196;
const double _headerH = 60;

class TapesTab extends StatefulWidget {
  const TapesTab({super.key});

  @override
  State<TapesTab> createState() => _TapesTabState();
}

class _TapesTabState extends State<TapesTab> {
  final ScrollController _sc = ScrollController();
  String? _bubble;

  @override
  void dispose() {
    _sc.dispose();
    super.dispose();
  }

  void _jump(String letter, List<Album> albums, bool hasPinned, LibraryStore store) {
    setState(() => _bubble = letter);
    if (albums.isEmpty || !_sc.hasClients) return;
    final target = letter == '#' ? 0 : letter.codeUnitAt(0) - 64;
    var best = 0;
    var bestD = 1 << 30;
    for (var i = 0; i < albums.length; i++) {
      final l = letterOf(store.keyOf(albums[i]));
      final code = l == '#' ? 0 : l.codeUnitAt(0) - 64;
      final d = (code - target).abs();
      if (d < bestD) {
        bestD = d;
        best = i;
        if (d == 0) break;
      }
    }
    final double base = (hasPinned ? _pinnedH : 0.0) + _headerH;
    final off = base + best * _rowH;
    _sc.jumpTo(math.min(off, _sc.position.maxScrollExtent));
  }

  @override
  Widget build(BuildContext context) {
    final store = context.watch<LibraryStore>();
    final albums = store.albums;
    final pinned = store.pinned;

    if (store.count == 0) {
      return const Center(
        child: Padding(
          padding: EdgeInsets.all(32),
          child: Text(
            'Your deck is empty.\nTap + and pick a .zip mixtape.',
            textAlign: TextAlign.center,
            style: TextStyle(color: kMuted, fontSize: 17, height: 1.6),
          ),
        ),
      );
    }

    return Stack(
      children: [
        Positioned.fill(
          child: CustomScrollView(
            controller: _sc,
            slivers: [
              if (pinned.isNotEmpty)
                SliverToBoxAdapter(
                  child: SizedBox(
                    height: _pinnedH,
                    child: ListView.separated(
                      scrollDirection: Axis.horizontal,
                      padding: const EdgeInsets.fromLTRB(16, 18, 16, 18),
                      itemCount: pinned.length,
                      separatorBuilder: (_, __) => const SizedBox(width: 14),
                      itemBuilder: (_, i) => _PinnedTile(album: pinned[i]),
                    ),
                  ),
                ),
              SliverToBoxAdapter(
                child: SizedBox(
                  height: _headerH,
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(20, 0, 8, 0),
                    child: Row(
                      children: [
                        const Text('All',
                            style: TextStyle(
                                fontSize: 28, fontWeight: FontWeight.w800)),
                        const Spacer(),
                        IconButton(
                          icon: const Icon(Icons.filter_list_rounded, size: 30),
                          onPressed: () => _showSort(context, store),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              if (albums.isEmpty)
                const SliverToBoxAdapter(
                  child: Padding(
                    padding: EdgeInsets.all(32),
                    child: Center(
                      child: Text('No tapes match.', style: TextStyle(color: kMuted)),
                    ),
                  ),
                )
              else
                SliverFixedExtentList(
                  itemExtent: _rowH,
                  delegate: SliverChildBuilderDelegate(
                    (c, i) => _AlbumRow(album: albums[i]),
                    childCount: albums.length,
                  ),
                ),
              const SliverToBoxAdapter(child: SizedBox(height: 130)),
            ],
          ),
        ),
        if (albums.length > 1)
          Positioned(
            right: 6,
            top: 0,
            bottom: 110,
            child: AlphabetBar(
              onLetter: (l) => _jump(l, albums, pinned.isNotEmpty, store),
              onEnd: () {
                if (mounted) setState(() => _bubble = null);
              },
            ),
          ),
        if (_bubble != null)
          Center(
            child: Container(
              width: 96,
              height: 96,
              alignment: Alignment.center,
              decoration: const BoxDecoration(
                color: Color(0xE6262626),
                shape: BoxShape.circle,
              ),
              child: Text(_bubble!,
                  style: const TextStyle(
                      fontSize: 48, fontWeight: FontWeight.w900, color: kOrange)),
            ),
          ),
      ],
    );
  }

  void _showSort(BuildContext context, LibraryStore store) {
    Widget opt(SortMode m, String label) => ListTile(
          title: Text(label),
          trailing: store.sort == m
              ? const Icon(Icons.check_rounded, color: kOrange)
              : null,
          onTap: () {
            store.setSort(m);
            Navigator.pop(context);
          },
        );
    showModalBottomSheet<void>(
      context: context,
      builder: (_) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Padding(
              padding: EdgeInsets.fromLTRB(20, 16, 20, 4),
              child: Align(
                alignment: Alignment.centerLeft,
                child: Text('Sort tapes',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
              ),
            ),
            opt(SortMode.titleAsc, 'Title  A to Z'),
            opt(SortMode.titleDesc, 'Title  Z to A'),
            opt(SortMode.artistAsc, 'Artist  A to Z'),
            opt(SortMode.newest, 'Recently added'),
          ],
        ),
      ),
    );
  }
}

class _PinnedTile extends StatelessWidget {
  const _PinnedTile({required this.album});

  final Album album;

  @override
  Widget build(BuildContext context) {
    final player = context.read<PlayerController>();
    return GestureDetector(
      onTap: () => Navigator.of(context).push(
          MaterialPageRoute<void>(builder: (_) => AlbumScreen(album: album))),
      onLongPress: () => showAlbumMenu(context, album),
      child: SizedBox(
        width: 160,
        height: 160,
        child: ClipRRect(
          borderRadius: BorderRadius.circular(22),
          child: Stack(
            fit: StackFit.expand,
            children: [
              CoverImage(path: album.coverPath, cacheWidth: 420),
              Positioned(
                left: 8,
                bottom: 8,
                child: GestureDetector(
                  onTap: () => player.playAlbum(album, 0),
                  child: Container(
                    width: 44,
                    height: 44,
                    decoration: BoxDecoration(
                      color: const Color(0xCC1A1A1A),
                      borderRadius: BorderRadius.circular(14),
                    ),
                    child: const Icon(Icons.play_arrow_rounded, size: 30),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _AlbumRow extends StatelessWidget {
  const _AlbumRow({required this.album});

  final Album album;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () => Navigator.of(context).push(
          MaterialPageRoute<void>(builder: (_) => AlbumScreen(album: album))),
      onLongPress: () => showAlbumMenu(context, album),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 9, 52, 9),
        child: Row(
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(14),
              child: SizedBox(
                width: 90,
                height: 90,
                child: CoverImage(path: album.coverPath, cacheWidth: 260),
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    album.title,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                        fontSize: 20, fontWeight: FontWeight.w500, height: 1.15),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    album.artist,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontSize: 17, color: kMuted),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
