import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../library_store.dart';
import '../models.dart';
import '../theme.dart';
import '../widgets/cover_image.dart';
import '../widgets/menus.dart';
import 'video_screen.dart';

class VideoTab extends StatelessWidget {
  const VideoTab({super.key});

  @override
  Widget build(BuildContext context) {
    final videos = context.watch<LibraryStore>().videos;

    if (videos.isEmpty) {
      return const Center(
        child: Padding(
          padding: EdgeInsets.all(32),
          child: Text(
            'No videos yet.\nTapes with .mp4 or .mov files show up here.',
            textAlign: TextAlign.center,
            style: TextStyle(color: kMuted, fontSize: 17, height: 1.6),
          ),
        ),
      );
    }

    return ListView.builder(
      padding: const EdgeInsets.only(bottom: 130, top: 4),
      itemCount: videos.length,
      itemBuilder: (_, i) => _VideoRow(item: videos[i]),
    );
  }
}

class _VideoRow extends StatelessWidget {
  const _VideoRow({required this.item});

  final TrackRef item;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () => Navigator.of(context).push(
          MaterialPageRoute<void>(builder: (_) => VideoScreen(item: item))),
      onLongPress: () => showTrackMenu(context, item),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 9, 16, 9),
        child: Row(
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(14),
              child: SizedBox(
                width: 90,
                height: 90,
                child: Stack(
                  fit: StackFit.expand,
                  children: [
                    CoverImage(path: item.album.coverPath, cacheWidth: 260),
                    const Center(
                      child: CircleAvatar(
                        radius: 18,
                        backgroundColor: Color(0xCC1A1A1A),
                        child: Icon(Icons.play_arrow_rounded, size: 24),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(item.track.title,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                          fontSize: 20, fontWeight: FontWeight.w500)),
                  const SizedBox(height: 4),
                  Text('${item.album.artist}  ·  ${item.album.title}',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontSize: 15, color: kMuted)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
