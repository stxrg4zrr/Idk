import 'dart:math';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../library_store.dart';
import '../models.dart';
import '../player_controller.dart';
import '../theme.dart';
import '../widgets/bottom_deck.dart';
import '../widgets/menus.dart';
import '../widgets/playlist_cover.dart';

/// Same layout as an album page: cover on top, tracks below (drag to reorder).
class PlaylistScreen extends StatelessWidget {
  const PlaylistScreen({super.key, required this.playlist});

  final Playlist playlist;

  @override
  Widget build(BuildContext context) {
    final store = context.watch<LibraryStore>();
    final pl = context.watch<PlayerController>();
    final tracks = store.playlistTracks(playlist);
    final curId = pl.current?.track.id;
    final color = Color(playlist.colorValue);

    return Scaffold(
      appBar: AppBar(
        actions: [
          PopupMenuButton<String>(
            icon: const Icon(Icons.more_vert),
            onSelected: (v) async {
              if (v == 'edit') {
                await showPlaylistEditor(context, existing: playlist);
              } else if (v == 'delete') {
                final nav = Navigator.of(context);
                await store.deletePlaylist(playlist);
                nav.maybePop();
              }
            },
            itemBuilder: (_) => [
              const PopupMenuItem(value: 'edit', child: Text('Edit playlist')),
              if (!playlist.isFavorites)
                const PopupMenuItem(value: 'delete', child: Text('Delete playlist')),
            ],
          ),
        ],
      ),
      bottomNavigationBar: const BottomDeck(showAdd: false),
      body: CustomScrollView(
        slivers: [
          SliverToBoxAdapter(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 48),
                  child: AspectRatio(
                    aspectRatio: 1,
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(14),
                      child: PlaylistCover(playlist: playlist, cacheWidth: 900),
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 22, 20, 4),
                  child: Text(playlist.name,
                      style: TextStyle(
                          fontSize: 28, fontWeight: FontWeight.w900, color: color)),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: Text('Playlist  ·  ${tracks.length} tracks',
                      style: const TextStyle(color: kMuted, fontSize: 16)),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 18, 20, 10),
                  child: Row(
                    children: [
                      FilledButton.icon(
                        style: FilledButton.styleFrom(
                          backgroundColor: color,
                          foregroundColor: Colors.black,
                          padding: const EdgeInsets.symmetric(
                              horizontal: 28, vertical: 16),
                        ),
                        onPressed:
                            tracks.isEmpty ? null : () => pl.playQueue(tracks, 0),
                        icon: const Icon(Icons.play_arrow_rounded),
                        label: const Text('PLAY',
                            style: TextStyle(
                                fontWeight: FontWeight.w900, fontSize: 16)),
                      ),
                      const SizedBox(width: 12),
                      IconButton.outlined(
                        onPressed: tracks.isEmpty
                            ? null
                            : () => pl.playQueue(
                                tracks, Random().nextInt(tracks.length),
                                shuffleOn: true),
                        icon: const Icon(Icons.shuffle_rounded),
                      ),
                    ],
                  ),
                ),
                if (tracks.isEmpty)
                  const Padding(
                    padding: EdgeInsets.all(28),
                    child: Text(
                      'Empty for now. Use the ⋮ menu on any track and pick "Add to playlist", or tap the heart on the player for Favorites.',
                      style: TextStyle(color: kMuted, height: 1.5),
                    ),
                  ),
              ],
            ),
          ),
          SliverReorderableList(
            itemCount: tracks.length,
            onReorder: (o, n) {
              if (n > o) n -= 1;
              store.reorderPlaylist(playlist, o, n);
            },
            itemBuilder: (c, i) {
              final r = tracks[i];
              final active = curId == r.track.id;
              return Material(
                key: ValueKey('${r.track.id}_$i'),
                color: kBlack,
                child: ListTile(
                  onTap: () => pl.playQueue(tracks, i),
                  contentPadding: const EdgeInsets.only(left: 20, right: 0),
                  leading: SizedBox(
                    width: 28,
                    child: Center(
                      child: active
                          ? Icon(pl.playing ? Icons.graphic_eq : Icons.pause,
                              color: color)
                          : Text('${i + 1}',
                              style: const TextStyle(color: kMuted)),
                    ),
                  ),
                  title: Text(
                    r.track.title,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w600,
                      color: active ? color : Colors.white,
                    ),
                  ),
                  subtitle: Text(
                    '${r.album.artist}  ·  ${r.album.title}',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(color: kMuted, fontSize: 13),
                  ),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      IconButton(
                        icon: const Icon(Icons.more_vert, color: kMuted),
                        onPressed: () =>
                            showTrackMenu(context, r, fromPlaylist: playlist),
                      ),
                      ReorderableDragStartListener(
                        index: i,
                        child: const Padding(
                          padding: EdgeInsets.only(right: 14, left: 4),
                          child: Icon(Icons.drag_handle, color: kMuted),
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
          const SliverToBoxAdapter(child: SizedBox(height: 24)),
        ],
      ),
    );
  }
}
