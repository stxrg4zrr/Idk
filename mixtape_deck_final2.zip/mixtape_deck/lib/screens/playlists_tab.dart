import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../library_store.dart';
import '../models.dart';
import '../player_controller.dart';
import '../theme.dart';
import '../widgets/menus.dart';
import '../widgets/playlist_cover.dart';
import 'playlist_screen.dart';

class PlaylistsTab extends StatelessWidget {
  const PlaylistsTab({super.key});

  @override
  Widget build(BuildContext context) {
    final store = context.watch<LibraryStore>();
    final lists = store.playlists;

    return ListView(
      padding: const EdgeInsets.only(bottom: 130),
      children: [
        const Padding(
          padding: EdgeInsets.fromLTRB(20, 8, 20, 8),
          child: Text('All',
              style: TextStyle(fontSize: 28, fontWeight: FontWeight.w800)),
        ),
        for (final pl in lists) _PlaylistRow(playlist: pl),
        const SizedBox(height: 8),
        Center(
          child: TextButton(
            onPressed: () => showPlaylistEditor(context),
            child: const Text('+ Create Playlist',
                style: TextStyle(color: kOrange, fontSize: 20)),
          ),
        ),
        const SizedBox(height: 24),
        Center(
          child: Text(
            '${store.playlists.where((x) => !x.isFavorites).length} Playlists  |  '
            '${store.playlistArtistTotal} Artists  |  '
            '${store.playlistTrackTotal} Tracks',
            style: const TextStyle(color: kOrange, fontSize: 17),
          ),
        ),
      ],
    );
  }
}

class _PlaylistRow extends StatelessWidget {
  const _PlaylistRow({required this.playlist});

  final Playlist playlist;

  @override
  Widget build(BuildContext context) {
    final store = context.read<LibraryStore>();
    final color = Color(playlist.colorValue);
    return InkWell(
      onTap: () => Navigator.of(context).push(MaterialPageRoute<void>(
          builder: (_) => PlaylistScreen(playlist: playlist))),
      onLongPress: () => _menu(context, store),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 9, 16, 9),
        child: Row(
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(14),
              child: SizedBox(
                width: 90,
                height: 90,
                child: PlaylistCover(playlist: playlist, cacheWidth: 260),
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(playlist.name,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                          fontSize: 24, fontWeight: FontWeight.w500, color: color)),
                  const SizedBox(height: 4),
                  Text('${playlist.trackIds.length} tracks',
                      style: const TextStyle(fontSize: 16, color: kMuted)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _menu(BuildContext context, LibraryStore store) {
    final player = context.read<PlayerController>();
    showModalBottomSheet<void>(
      context: context,
      builder: (sheet) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.play_arrow_rounded, color: kOrange),
              title: const Text('Play'),
              onTap: () {
                Navigator.pop(sheet);
                final t = store.playlistTracks(playlist);
                if (t.isNotEmpty) player.playQueue(t, 0);
              },
            ),
            ListTile(
              leading: const Icon(Icons.edit_outlined, color: kOrange),
              title: const Text('Edit (name, color, cover)'),
              onTap: () {
                Navigator.pop(sheet);
                showPlaylistEditor(context, existing: playlist);
              },
            ),
            if (!playlist.isFavorites)
              ListTile(
                leading: const Icon(Icons.delete_outline, color: Colors.redAccent),
                title: const Text('Delete playlist'),
                onTap: () {
                  Navigator.pop(sheet);
                  store.deletePlaylist(playlist);
                },
              ),
          ],
        ),
      ),
    );
  }
}
