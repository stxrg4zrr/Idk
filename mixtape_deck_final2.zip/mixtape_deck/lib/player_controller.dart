import 'dart:async' show unawaited;
import 'dart:io';
import 'dart:math';

import 'package:audio_service/audio_service.dart' show MediaItem;
import 'package:flutter/foundation.dart';
import 'package:just_audio/just_audio.dart';

import 'models.dart';
import 'utils.dart';

/// One audio player for the whole app. Uses just_audio_background so the track
/// shows in the lock screen and in the quick-settings media card.
class PlayerController extends ChangeNotifier {
  PlayerController() {
    player.currentIndexStream.listen((i) {
      index = i ?? -1;
      notifyListeners();
    });
    player.playerStateStream.listen((s) {
      playing = s.playing && s.processingState != ProcessingState.completed;
      notifyListeners();
    });
    player.shuffleModeEnabledStream.listen((v) {
      shuffle = v;
      notifyListeners();
    });
    player.loopModeStream.listen((v) {
      loop = v;
      notifyListeners();
    });
    player.playbackEventStream.listen((_) {}, onError: (Object e, StackTrace st) {
      // Unplayable file: jump to the next one.
      if (player.hasNext) unawaited(player.seekToNext());
    });
  }

  final AudioPlayer player = AudioPlayer();
  ConcatenatingAudioSource? _source;
  int _uid = 0;

  List<TrackRef> queue = [];
  int index = -1;
  bool playing = false;
  bool shuffle = false;
  LoopMode loop = LoopMode.off;

  TrackRef? get current =>
      (index >= 0 && index < queue.length) ? queue[index] : null;

  Stream<Duration> get positionStream => player.positionStream;
  Stream<Duration?> get durationStream => player.durationStream;

  AudioSource _src(TrackRef r) {
    final cp = r.album.coverPath;
    final cover = (cp != null && File(cp).existsSync()) ? cp : defaultCoverPath;
    return AudioSource.uri(
      Uri.file(r.track.path),
      tag: MediaItem(
        id: '${r.track.id}#${_uid++}',
        album: r.album.title,
        title: r.track.title,
        artist: r.album.artist,
        artUri: Uri.file(cover),
      ),
    );
  }

  Future<void> playQueue(List<TrackRef> items, int start,
      {bool shuffleOn = false}) async {
    if (items.isEmpty) return;
    queue = List.of(items);
    final src = ConcatenatingAudioSource(children: items.map(_src).toList());
    _source = src;
    try {
      await player.setShuffleModeEnabled(shuffleOn);
      await player.setAudioSource(
        src,
        initialIndex: clampInt(start, 0, items.length - 1),
        initialPosition: Duration.zero,
      );
      if (shuffleOn) await player.shuffle();
      unawaited(player.play());
    } catch (_) {}
    notifyListeners();
  }

  Future<void> playAlbum(Album a, int start) =>
      playQueue(a.tracks.map((t) => TrackRef(t, a)).toList(), start);

  /// Puts tracks right after the one that is playing.
  Future<void> playNextMany(List<TrackRef> items) async {
    if (items.isEmpty) return;
    final src = _source;
    if (src == null || queue.isEmpty) {
      await playQueue(items, 0);
      return;
    }
    var at = min(queue.length, max(0, index + 1));
    final first = at;
    for (final r in items) {
      queue.insert(at, r);
      await src.insert(at, _src(r));
      at++;
    }
    await _resumeIfFinished(first);
    notifyListeners();
  }

  /// Adds tracks to the end of the queue.
  Future<void> addManyToQueue(List<TrackRef> items) async {
    if (items.isEmpty) return;
    final src = _source;
    if (src == null || queue.isEmpty) {
      await playQueue(items, 0);
      return;
    }
    final first = queue.length;
    for (final r in items) {
      queue.add(r);
      await src.add(_src(r));
    }
    await _resumeIfFinished(first);
    notifyListeners();
  }

  Future<void> _resumeIfFinished(int jumpTo) async {
    if (player.processingState == ProcessingState.completed) {
      await player.seek(Duration.zero, index: jumpTo);
      unawaited(player.play());
    }
  }

  Future<void> jumpTo(int i) async {
    if (i < 0 || i >= queue.length) return;
    await player.seek(Duration.zero, index: i);
    unawaited(player.play());
  }

  Future<void> removeAt(int i) async {
    final src = _source;
    if (src == null || i < 0 || i >= queue.length) return;
    if (queue.length == 1) {
      await stop();
      return;
    }
    queue.removeAt(i);
    await src.removeAt(i);
    notifyListeners();
  }

  Future<void> move(int from, int to) async {
    final src = _source;
    if (src == null || from == to) return;
    final it = queue.removeAt(from);
    queue.insert(to, it);
    await src.move(from, to);
    notifyListeners();
  }

  Future<void> toggle() async {
    if (current == null) return;
    if (player.playing) {
      await player.pause();
    } else {
      unawaited(player.play());
    }
  }

  Future<void> pause() async {
    if (player.playing) await player.pause();
  }

  Future<void> next() async {
    if (player.hasNext) await player.seekToNext();
  }

  Future<void> previous() async {
    if (player.position > const Duration(seconds: 3) || !player.hasPrevious) {
      await player.seek(Duration.zero);
    } else {
      await player.seekToPrevious();
    }
  }

  Future<void> seek(Duration d) => player.seek(d);

  Future<void> toggleShuffle() async {
    final on = !player.shuffleModeEnabled;
    await player.setShuffleModeEnabled(on);
    if (on) await player.shuffle();
  }

  Future<void> cycleLoop() async {
    final next = loop == LoopMode.off
        ? LoopMode.all
        : (loop == LoopMode.all ? LoopMode.one : LoopMode.off);
    await player.setLoopMode(next);
  }

  Future<void> stop() async {
    await player.stop();
    queue = [];
    _source = null;
    index = -1;
    playing = false;
    notifyListeners();
  }

  @override
  void dispose() {
    player.dispose();
    super.dispose();
  }
}
